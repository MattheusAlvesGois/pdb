<?php

$host="localhost";
$database="concessionaria";
$password="zero";
$username="root";

$mysqli = new mysqli($host, $username, $password);

mysqli_select_db ($mysqli, $database);
?>