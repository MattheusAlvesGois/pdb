<?php
include('conectar.php');

if(isset($_POST['email'])) {

    if(strlen($_POST['email']) == 0) {
        echo "Preencha seu e-mail";
    } else if (strlen($_POST['senha']) == 0) {
        echo "Preencha sua senha";
    } else {
        $email = $mysqli->real_escape_string($_POST['email']);
        $senha = $mysqli->real_escape_string($_POST['senha']);
        
        $sql_code = "SELECT * FROM funcionarios WHERE email = '$email' LIMIT 1";
        $sql_exec = $mysqli->query($sql_code) or die($mysqli->error);

        $usuario = $sql_exec->fetch_assoc();
        if(password_verify($senha, $usuario['senha'])) {
            if(!isset($_SESSION)) {
                session_start();
    }
        $_SESSION['idfunc'] = $usuario['idfunc'];
        $_SESSION['nome'] = $usuario['nome'];
        header("Location: principal.php");
    } else {
        echo"Falha no Login! Senha ou E-mail incorretos.";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-box">
        <div class="login">
    <form action="" method="POST">
        <h1>Login</h1>
        <p>
        <label>Email</label>
        <input type="text" name="email" autofocus>
        </p>
        <p>
            <label>Senha</label>
            <input type="text" name="senha">
        </p>
        <p>
            <button type="submit">Entrar</button>
        </p>
    </form>
</div>
</div>
</body>
</html> 