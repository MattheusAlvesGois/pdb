<?php

    require_once 'conectar.php';
    if (isset($_POST['cadastrar'])) {
        $nome = $_POST['nome'];
        $senha = $_POST['senha'];
        $email = $_POST['email'];
        $cpf = $_POST['cpf'];
        $telefone = $_POST['telefone'];
        $rg = $_POST['rg'];
        $estado = $_POST['estado'];
        $cidade = $_POST['cidade'];

        $hash = password_hash($senha, PASSWORD_DEFAULT);
        
    $sql = mysqli_query($mysqli,"INSERT INTO usuarios VALUES (0, '$nome', '$hash', '$email', '$cpf', '$telefone', '$rg', '$estado', '$cidade')");
    
    }
?>