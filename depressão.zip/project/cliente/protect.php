<?php

if(!isset($_SESSION)) {
    session_start();
}

if(!isset($_SESSION['idclient'])) {
    die("Faça login para continuar para esta página.");
}

?>