<?php

$host="localhost";
$database="concessionaria";
$password="zero";
$username="root";

$mysqli = new mysqli($host, $username, $password);

$criardb = "CREATE DATABASE IF NOT EXISTS concessionaria";
mysqli_query($mysqli, $criardb);

mysqli_select_db ($mysqli, $database);
?>