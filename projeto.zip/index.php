<?php

require_once 'conectar.php';

$core = "CREATE DATABASE IF NOT EXISTS concessionaria";
mysqli_query($mysqli, $core);

$tabela1= "CREATE TABLE IF NOT EXISTS usuarios(
    idclient bigint(20) auto_increment not null primary key,
    nome varchar(120) not null,
    senha varchar(50) not null,
    email varchar(150) not null,
    cpf varchar(30) not null,
    telefone varchar(30) not null,
    rg varchar(30) not null,
    estado varchar(150) not null,
    cidade varchar(150) not null) ENGINE = MYISAM;";

mysqli_query($mysqli, $tabela1);

$tabela2 = "CREATE TABLE IF NOT EXISTS funcionarios(
    idfunc bigint(20) auto_increment not null primary key,
    nome varchar(120) not null,
    senha varchar(50) not null,
    email varchar(150) not null,
    cpf varchar(30) not null,
    telefone varchar(30) not null,
    rg varchar(30) not null,
    estado varchar(150) not null,
    cidade varchar(150) not null,
    cnh varchar(50) not null,
    pis varchar(50) not null,
    endereco varchar(150) not null) ENGINE = MYISAM;";

mysqli_query($mysqli, $tabela2);

$tabela3 = "CREATE TABLE IF NOT EXISTS marcas(
    idmarca bigint(20) auto_increment not null primary key,
    marca varchar(120) not null) ENGINE = MYISAM;";

mysqli_query($mysqli, $tabela3);

$tabela4 = "CREATE TABLE IF NOT EXISTS veiculos(
    idveic bigint(20) auto_increment not null primary key,
    modelo varchar(100) not null,
    idmarca bigint(20) not null,
    cor varchar(100) not null,
    ano varchar(5) not null,
    preco decimal not null,
    nchassi varchar(100) not null,
    foto varchar(100) not null,
    FOREIGN KEY (idmarca) REFERENCES marcas(idmarca)) ENGINE = MYISAM;";

mysqli_query($mysqli, $tabela4);

$tabela5 = "CREATE TABLE IF NOT EXISTS promocoes(
    idveic bigint(20) not null,
    datafinal date not null,
    taxaperc decimal not null,
    FOREIGN KEY (idveic) REFERENCES veiculos(idveic)) ENGINE = MYISAM;";

mysqli_query($mysqli, $tabela5);

$tabela6 = "CREATE TABLE IF NOT EXISTS vendas(
    idvenda bigint(20) auto_increment not null primary key,
    idveic bigint(20) not null,
    idclient bigint(20) not null,
    idfunc bigint(20) not null,
    datavenda date not null,
    FOREIGN KEY (idveic) REFERENCES veiculos(idveic),
    FOREIGN KEY (idclient) REFERENCES usuarios(idclient),
    FOREIGN KEY (idfunc) REFERENCES funcionarios(idfunc)) ENGINE = MYISAM;";

mysqli_query($mysqli, $tabela6);

$tabela7 = "CREATE TABLE IF NOT EXISTS pecas(
    idpeças bigint(20) auto_increment primary key not null,
    nome varchar(150) not null,
    descricao varchar(1000) not null,
    foto varchar(150) not null,
    preco decimal not null) ENGINE = MYISAM;";

mysqli_query($mysqli, $tabela7);

header('Location:cadastro.html');